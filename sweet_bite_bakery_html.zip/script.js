const PRODUCTS = [
  { id: 1, name: 'Chocolate Fudge Cake', description: 'Rich chocolate cake with smooth ganache.', price: 1800, image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=700', category: 'Cakes' },
  { id: 2, name: 'Strawberry Cupcakes', description: 'Soft cupcakes topped with strawberry frosting.', price: 450, image: 'https://images.unsplash.com/photo-1486427944299-d1955d23e34d?w=700', category: 'Cupcakes' },
  { id: 3, name: 'Classic Donuts', description: 'Freshly baked donuts with a sweet glaze.', price: 250, image: 'https://images.unsplash.com/photo-1551024506-0bc0e5e7a5f4?w=700', category: 'Donuts' },
  { id: 4, name: 'Vanilla Birthday Cake', description: 'Light vanilla sponge for your special day.', price: 2200, image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=700', category: 'Cakes' }
];

function validateOrderForm() {
  const quantity = Number(document.getElementById('quantity').value);
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 20) {
    alert('Please enter a quantity between 1 and 20.');
    return false;
  }
  return true;
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

document.addEventListener('DOMContentLoaded', () => {
  // Set current year in footer if placeholder exists
  const yearEl = document.getElementById('current-year');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  // Order Page Logic
  const orderForm = document.getElementById('order-form');
  const product = document.getElementById('product');
  const quantity = document.getElementById('quantity');
  const total = document.getElementById('total');
  const noticeBox = document.getElementById('order-notice');

  if (product) {
    const params = new URLSearchParams(window.location.search);
    const selectedId = params.get('product');
    if (selectedId) {
      product.value = selectedId;
    }
  }

  function updateTotal() {
    if (!product || !quantity || !total) return;
    const option = product.options[product.selectedIndex];
    const price = Number(option?.dataset.price || 0);
    const qty = Number(quantity.value || 0);
    total.textContent = price && qty ? 'Rs. ' + (price * qty).toLocaleString('en-PK') : 'Select a product';
  }

  if (product && quantity && total) {
    product.addEventListener('change', updateTotal);
    quantity.addEventListener('input', updateTotal);
    updateTotal();
  }

  if (orderForm) {
    orderForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!validateOrderForm()) return;

      const formData = new FormData(orderForm);
      const customer_name = (formData.get('customer_name') || '').trim();
      const email = (formData.get('email') || '').trim();
      const phone = (formData.get('phone') || '').trim();
      const address = (formData.get('address') || '').trim();
      const productId = Number(formData.get('product_id') || 0);
      const qty = Number(formData.get('quantity') || 1);
      const notes = (formData.get('notes') || '').trim();

      const selectedProd = PRODUCTS.find(p => p.id === productId);
      if (!customer_name || !email || !phone || !address || !selectedProd || qty < 1 || qty > 20) {
        if (noticeBox) {
          noticeBox.style.display = 'block';
          noticeBox.textContent = 'Please complete all required fields correctly. Quantity must be between 1 and 20.';
        }
        return;
      }

      const orderTotal = selectedProd.price * qty;
      const existingOrders = JSON.parse(localStorage.getItem('sweet_bite_orders') || '[]');
      const nextId = existingOrders.length > 0 ? Math.max(...existingOrders.map(o => o.id)) + 1 : 1;

      const newOrder = {
        id: nextId,
        customer_name,
        email,
        phone,
        address,
        product_id: productId,
        product_name: selectedProd.name,
        quantity: qty,
        total: orderTotal,
        notes,
        created_at: new Date().toISOString().slice(0, 19).replace('T', ' ')
      };

      existingOrders.unshift(newOrder);
      localStorage.setItem('sweet_bite_orders', JSON.stringify(existingOrders));

      if (noticeBox) {
        noticeBox.style.display = 'block';
        noticeBox.textContent = `Thank you, ${customer_name}! Your order has been received. Your total is Rs. ${orderTotal.toLocaleString('en-PK')}.`;
      }
      orderForm.reset();
      updateTotal();
    });
  }

  // Admin Orders Page Logic
  const ordersBody = document.getElementById('orders-tbody');
  if (ordersBody) {
    const orders = JSON.parse(localStorage.getItem('sweet_bite_orders') || '[]');
    if (orders.length === 0) {
      ordersBody.innerHTML = '<tr><td colspan="6">No orders have been received yet.</td></tr>';
    } else {
      ordersBody.innerHTML = orders.map(o => `
        <tr>
          <td>#${Number(o.id)}</td>
          <td>${escapeHtml(o.customer_name)}<br><small>${escapeHtml(o.phone)}</small></td>
          <td>${escapeHtml(o.product_name)}</td>
          <td>${Number(o.quantity)}</td>
          <td>Rs. ${Number(o.total).toLocaleString('en-PK')}</td>
          <td>${escapeHtml(o.created_at)}</td>
        </tr>
      `).join('');
    }
  }
});
